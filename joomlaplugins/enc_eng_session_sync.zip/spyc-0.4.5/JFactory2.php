<?php
class JFactory2 extends JFactory
{

function &_createDBO()
   {
      jimport('joomla.database.database');
      jimport( 'joomla.database.table' );

      $conf =& JFactory::getConfig();

      $host       = $conf->getValue('config.host'); //change this value or leave it intact if host is the same
      $user       = $conf->getValue('config.user'); //change this value or leave it intact if user is the same
      $password    = $conf->getValue('config.password'); //change this value or leave it intact if host is the same
      $database   =  "enc";
      $prefix    = $conf->getValue(''); //in fact, we don't need this
      $driver    = $conf->getValue('config.dbtype');
      $debug       = $conf->getValue('config.debug');

      $options   = array ( 'driver' => $driver, 'host' => $host, 'user' => $user, 'password' => $password, 'database' => $database, 'prefix' => $prefix );

      $db =& JDatabase::getInstance( $options );

      if ( JError::isError($db) ) {
         jexit('Database Error: ' . $db->toString() );
      }

      if ($db->getErrorNum() > 0) {
         JError::raiseError(500 , 'JDatabase::getInstance: Could not connect to database <br />' . 'joomla.library:'.$db->getErrorNum().' - '.$db->getErrorMsg() );
      }

      $db->debug( $debug );
      return $db;
   }

   function &getDBO()
   {
      static $instance2;

      if (!is_object($instance2))
      {
         //get the debug configuration setting
         $conf =& JFactory::getConfig();
         $debug = $conf->getValue('config.debug');

         $instance2 = JFactory2::_createDBO();
         $instance2->debug($debug);
      }

      return $instance2;
   }

}
?>
