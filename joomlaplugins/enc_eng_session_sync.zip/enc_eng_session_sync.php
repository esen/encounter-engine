<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
*/

include_once(JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'spyc-0.4.5'.DS.'JFactory2.php');
include_once(JPATH_ROOT.DS.'plugins'.DS.'system'.DS.'spyc-0.4.5'.DS.'spyc.php');

$user	= &JFactory::getUser();
$ses	= &JFactory::getSession();
$db_jom	= &JFactory::getDBO();
$db_enc	= &JFactory2::getDBO();

$user_id	= $user->get('id');
$ses_name_jom	= $ses->getName();
$ses_name_enc	= '_encounter-engine_session_id';
$ses_id_jom	= $ses->getID();
$ses_id_enc	= $_COOKIE[$ses_name_enc];

global $mainframe;

$db_enc->setQuery("SELECT * FROM sessions WHERE session_id='$ses_id_enc'");
$enc_ses_raw = $db_enc->loadObject();
$enc_data = Spyc::YAMLLoad($enc_ses_raw->data);

if (!$user_id) {
    if ($enc_data['user']>0) {
	
	$db_jom->setQuery("SELECT * FROM #__users WHERE id={$enc_data['user']}");
	$userdet = $db_jom->loadObject();

	if ($userdet->id = $enc_data['user']) {
	    $options = array();
	    $options['encounter_authenticated'] = true;
	    $options['user_id'] = $enc_data['user'];

	    $credentials = array();
	    $credentials['username'] = $userdet->username;
	    $credentials['password'] = 'password';

	    $mainframe->login($credentials, $options);
	}
    }
} else {
    if (!$enc_data['user']) {

	if (!$ses_id_enc && $user->usertype=='Registered') {
	    $ses_id_enc = $ses_id_jom;
	    setcookie($ses_name_enc, $ses_id_enc);
	}

	if ($enc_ses_raw->id) {
	    $query = "UPDATE sessions SET `data` = '---\nreturn_to: \nauthentication_strategies: \nuser: {$user_id}\n' "
//		    .", updated_at='".date("Y-m-d H:i:s")."' "
		    ."WHERE session_id='{$ses_id_enc}'";
	} else {
	    $query = "INSERT INTO sessions (session_id, data, updated_at) VALUES ("
		    ."'{$ses_id_enc}', '---\nreturn_to: \nauthentication_strategies: \nuser: {$user_id}\n'"
		    .", '".date("Y-m-d H:i:s")."')";
	}

	$db_enc->setQuery($query);
	$db_enc->query();
    }
}
?>

